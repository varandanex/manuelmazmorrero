import { WIDTH, HEIGHT, PILLARS } from './game.js';

const PAL = { '.': null, o: '#1b1524', h: '#44313b', H: '#685052', s: '#d5a477', S: '#a9755d', e: '#211824', c: '#b76361', C: '#e98b79', p: '#64617e', P: '#8a87a0', b: '#352b3c', g: '#e8bb70', w: '#eee3c9', W: '#dfd6c0', t: '#9ac9b1', T: '#d5f0c4', v: '#80678f', V: '#ae86b8', r: '#ed847f', k: '#41384c', m: '#8fa86a', M: '#bfd38a', n: '#627d59', z: '#c2b1d5' };
const SPRITES = {
  hero: [
    '.....hhhhhh.....', '....hhHHHHhh....', '...hhHHHHHhhh...', '...hhssssshhh...', '...hssessesho...', '....sSsssSs.....', '.....hSShh......', '....ccggccc.....', '...cCCCCcccs....', '..sccCCCcccss...', '..sscccccchs....', '....gggggg......', '....pppppp......', '....pPppPp......', '....pp..pp......', '...bbb..bbb.....',
  ],
  grunt: [
    '....oo.....oo...', '...onnn...nnno..', '...nmnnnnnmno...', '..onnMMMMMnno...', '..nnMMMrMrMnn...', '.onnMMnnnnMnn...', '.onnnnMwwMnnno..', '..nnnnnnnnnno...', '...nmmnmmnno....', '..nmmmmmnnnn....', '.nnnmmmmnnnno...', '.nnnnnnnnnnno...', '...nnn..nnn.....', '..oooo..oooo....',
  ],
  bat: [
    '.o............o.', 'ovo..........ovo', 'ovvo..o..o..ovvo', 'ovVvo.ovvo.ovVvo', 'ovVVvovVVvovVVvo', '.ovVVvvrrvvVVvo.', '..ovvvvVVvvvvo..', '...oovVwwVvoo...', '.....ovvvvo.....', '......oooo......',
  ],
  caster: [
    '......vvv.......', '.....vVVvv......', '....vVVVvvv.....', '...vVVVVvvvv....', '..vVVoooovvvv...', '..vVotTTooovv...', '...vooTTovvv....', '....vvvvvvv.....', '...vVvvzvvVv....', '..vVVvvzvvVVv...', '.vVVVvvzvvVVVv..', '.vvvvvvzvvvvvv..', '..vvvvgzgvvvv...', '....vvvvvvv.....', '...ooooooooo....',
  ],
  butcher: [
    '.........hhhhhh.........', '........hhHHHHhh........', '.......hHsssssshh.......', '.......hsssSSsssh.......', '.......ssreSSerss.......', '.......ssSssssSss.......', '........SwwwwwSS........', '.....SSssSSSSssssSS.....', '...SSssssswWwsssssssS...', '..SsssssswwwwwwssssssS..', '.SsssssswwcwwwwsssssssS.', '.SsssssswwccwwwsssssssS.', '.SssssSwwwwwwwcwSssssS..', '..ssssSwwwwwccwwSssss...', '..sss.SwwwwwwwwwS.sss...', '..SS..SwwccwwwwwS..SS...', '......SwwwwwwwwwS.......', '.......ggggggggg........', '.......ppppppppp........', '.......pppp.pppp........', '.......pppp.pppp........', '......bbbbb.bbbbb.......', '.....bbbbbb.bbbbbb......',
  ],
  spore: [
    '.........nnnnnn.........', '.......nnmmMMmmnn.......', '.....nnmmMMMMMMmmnn.....', '....nmmMMwwMMMMMMmmn....', '...nmmMMMwwMMMMwwMmmn...', '..nmmMMMMMMMMMMwwMMmmn..', '.nmmwwMMMMMMMMMMMMMMmmn.', '.nmmwwMMMMMwwwwMMMMMmmn.', 'nmmMMMMMMMMwwwwMMMMMMmmn', 'nmmmmMMMMMMMMMMMMMMmmmmn', 'nnnnmmmmmmmmmmmmmmmmnnnn', '.nnnnnnnnnnnnnnnnnnnnnn.', '.....nssSSSSSSsssn......', '......ssrrSSrrss........', '......ssSssssSss........', '......ssSwwwwSss........', '.....ssSSssssSSss.......', '....ssSSSSssSSSSss......', '...nnSSSSSSSSSSSSnn.....', '..nnnnSSSSSSSSSSnnnn....', '.nnnnnnnnnnnnnnnnnnnn...',
  ],
  host: [
    '........gggggggg........', '......gggggggggggg......', '.....gvvvvvvvvvvvvg.....', '....gvVVVVVVVVVVVvvg....', '...gvVVVzzzzzzVVVVvvg...', '...gvVVzzwwwwzzVVVvvg...', '...gvVzzwwwwwwzzVVvvg...', '...gvVzwwoooowwzVVvvg...', '...gvVzwwoTTowwzVVvvg...', '...gvVzwwoooowwzVVvvg...', '...gvVzzwwwwwwzzVVvvg...', '...gvVVzzwwwwzzVVVvvg...', '...gvVVVzzzzzzVVVVvvg...', '....gvVVVVVVVVVVVvvg....', '.....gvvvvvvvvvvvvg.....', '......gggggggggggg......', '........gggggggg........', '.........vvvVvv.........', '........vvvVvvvv........', '.......vvvVVvvvvv.......', '......vvvVVVVvvvvv......', '.....vvvvvvvvvvvvvv.....',
  ],
  generator: [
    '......gggg......', '.....gVVVVg.....', '....gVzzzzVg....', '....gVzTTzVg....', '....gVzTTzVg....', '.....gVzzVg.....', '......gVVg......', '......vvvv......', '.....kkkkkk.....', '....kppppppk....', '....kpzppzpk....', '....kppppppk....', '...kkkkkkkkkk...', '...kkkkkkkkkk...',
  ],
  skull: ['..wwww..', '.wwwwww.', '.woowoo.', '.woowoo.', '..wwww..', '..w.w...', '.wwwww..'],
};

const cache = new Map();
const theme = [
  { tile: '#302736', tile2: '#342b3b', grout: '#241e2c', wall: '#4d3e51', wall2: '#443549', light: '#775b70', accent: '#b67a9b' },
  { tile: '#28332e', tile2: '#2d3931', grout: '#202a27', wall: '#404e43', wall2: '#37463b', light: '#62735d', accent: '#9ac982' },
  { tile: '#2c2a3c', tile2: '#312e42', grout: '#221f30', wall: '#48405e', wall2: '#3e3753', light: '#71618e', accent: '#af92d5' },
];

function sprite(ctx, name, x, y, scale = 2, flash = false) {
  const rows = SPRITES[name];
  const left = Math.round(x - rows[0].length * scale / 2), top = Math.round(y - rows.length * scale + 10);
  for (let row = 0; row < rows.length; row++) for (let col = 0; col < rows[row].length; col++) {
    const color = PAL[rows[row][col]];
    if (!color) continue;
    ctx.fillStyle = flash ? '#fff0d5' : color;
    ctx.fillRect(left + col * scale, top + row * scale, Math.ceil(scale), Math.ceil(scale));
  }
}

function stone(ctx, x, y, w, h, base, highlight) {
  ctx.fillStyle = '#17121e'; ctx.fillRect(x, y + 3, w, h);
  ctx.fillStyle = base; ctx.fillRect(x, y, w, h - 2);
  ctx.fillStyle = highlight; ctx.fillRect(x + 1, y, w - 2, 2);
  ctx.fillStyle = '#17121e33'; ctx.fillRect(x + w - 3, y + 3, 3, h - 5);
}

function staticRoom(floor) {
  if (cache.has(floor)) return cache.get(floor);
  const canvas = document.createElement('canvas'); canvas.width = WIDTH; canvas.height = HEIGHT;
  const ctx = canvas.getContext('2d'); const t = theme[floor];
  ctx.fillStyle = '#100e17'; ctx.fillRect(0, 0, WIDTH, HEIGHT);
  ctx.fillStyle = t.grout; ctx.fillRect(28, 56, 424, 337);
  for (let row = 0; row < 11; row++) for (let col = 0; col < 14; col++) {
    const x = 30 + col * 30, y = 60 + row * 30;
    ctx.fillStyle = (col * 13 + row * 7) % 5 < 2 ? t.tile2 : t.tile;
    ctx.fillRect(x, y, 28, 28);
    ctx.fillStyle = '#ffffff05'; ctx.fillRect(x + 1, y, 25, 1);
    if ((row * 31 + col * 17) % 7 === 0) {
      ctx.fillStyle = t.grout; ctx.fillRect(x + 7, y + 8, 2, 8); ctx.fillRect(x + 9, y + 14, 7, 2);
    }
    if ((row + col * 3) % 4 === 0) { ctx.fillStyle = '#a79bb10c'; ctx.fillRect(x + 20, y + 20, 3, 2); }
  }
  ctx.strokeStyle = `${t.accent}22`; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(240, 222, 67, 0, Math.PI * 2); ctx.stroke();
  ctx.beginPath(); ctx.arc(240, 222, 61, 0, Math.PI * 2); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(240, 173); ctx.lineTo(283, 246); ctx.lineTo(197, 246); ctx.closePath(); ctx.stroke();
  for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; ctx.fillStyle = `${t.accent}33`; ctx.fillRect(239 + Math.cos(a) * 77, 221 + Math.sin(a) * 77, 3, 3); }
  for (let row = 0; row < 3; row++) for (let col = 0; col < 12; col++) {
    const x = 3 + col * 42 + (row % 2 ? -20 : 0);
    stone(ctx, x, 9 + row * 16, 40, 15, row % 2 ? t.wall : t.wall2, t.light);
  }
  for (let y = 58; y < 393; y += 27) {
    stone(ctx, 8, y, 20, 25, t.wall2, t.light); stone(ctx, 452, y, 20, 25, t.wall2, t.light);
  }
  ctx.fillStyle = '#0c0a12'; ctx.fillRect(215, 9, 50, 49); ctx.fillRect(223, 2, 34, 8);
  for (let i = 0; i < 5; i++) { ctx.fillStyle = ['#201925', '#2a2130', '#342a3d', '#40324a', '#4b3b56'][i]; ctx.fillRect(216, 23 + i * 7, 48, 5); }
  stone(ctx, 205, 8, 10, 49, t.wall, t.light); stone(ctx, 265, 8, 10, 49, t.wall, t.light);
  stone(ctx, 213, 2, 54, 9, t.wall, t.light);
  for (let x = 8; x < 472; x += 29) stone(ctx, x, 393, 27, 15, t.wall2, t.light);
  ctx.fillStyle = '#0d0a1266'; ctx.fillRect(28, 58, 424, 13); ctx.fillRect(28, 58, 8, 335);
  for (let i = 0; i < 26; i++) {
    const x = 38 + ((i * 113) % 400), y = 76 + ((i * 71) % 300);
    if (Math.abs(x - 240) < 90 && Math.abs(y - 222) < 90) continue;
    ctx.fillStyle = i % 2 ? '#a494b01b' : '#0c09194d'; ctx.fillRect(x, y, 3 + i % 4, 2);
  }
  sprite(ctx, 'skull', 51, 352, 1.5); sprite(ctx, 'skull', 425, 117, 1);
  ctx.fillStyle = '#a2938b66'; ctx.fillRect(419, 348, 15, 2); ctx.fillRect(421, 346, 2, 6); ctx.fillRect(431, 346, 2, 6);
  // Banners and chains belong to the room, not to the collision map.
  for (const x of [146, 322]) {
    ctx.fillStyle = '#201a29'; ctx.fillRect(x - 1, 17, 19, 42);
    ctx.fillStyle = floor === 1 ? '#657449' : '#7c455e'; ctx.fillRect(x, 17, 16, 35);
    ctx.fillRect(x + 2, 52, 5, 5); ctx.fillRect(x + 9, 52, 5, 5);
    ctx.fillStyle = '#e8bb7077'; ctx.fillRect(x + 7, 27, 2, 13); ctx.fillRect(x + 3, 31, 10, 2);
    ctx.fillStyle = '#baa47a'; ctx.fillRect(x - 3, 15, 23, 3);
  }
  if (floor === 1) for (const x of [37, 433]) for (let y = 85; y < 375; y += 25) {
    ctx.fillStyle = '#65744977'; ctx.fillRect(x, y, 5, 16); ctx.fillRect(x - 3, y + 3, 11, 4);
  }
  cache.set(floor, canvas); return canvas;
}

function pillar(ctx, p, floor) {
  const t = theme[floor];
  ctx.fillStyle = '#09071266'; ctx.fillRect(p.x - 18, p.y + 1, 40, 19);
  stone(ctx, p.x - 17, p.y - 6, 34, 19, t.wall2, t.light);
  stone(ctx, p.x - 12, p.y - 32, 24, 28, t.wall, t.light);
  ctx.fillStyle = t.wall2; ctx.fillRect(p.x - 6, p.y - 29, 4, 22); ctx.fillRect(p.x + 4, p.y - 29, 4, 22);
  stone(ctx, p.x - 16, p.y - 39, 32, 10, t.wall, t.light);
}

function torch(ctx, x, y, time, floor) {
  const flicker = Math.sin(time * 9 + x) * 2;
  const glow = ctx.createRadialGradient(x, y, 1, x, y, 60 + flicker);
  glow.addColorStop(0, floor === 2 ? '#b996e52a' : '#edaa602c'); glow.addColorStop(1, '#edaa6000');
  ctx.fillStyle = glow; ctx.fillRect(x - 65, y - 65, 130, 130);
  ctx.fillStyle = '#211a27'; ctx.fillRect(x - 5, y + 3, 10, 10);
  ctx.fillStyle = '#8a6253'; ctx.fillRect(x - 2, y + 2, 4, 12);
  ctx.fillStyle = floor === 2 ? '#977cbd' : '#cc7955'; ctx.fillRect(x - 5, y - 10 + flicker, 10, 13 - flicker);
  ctx.fillStyle = floor === 2 ? '#c2a1e5' : '#edb86f'; ctx.fillRect(x - 3, y - 12 - flicker, 6, 13 + flicker);
  ctx.fillStyle = '#f6e3ba'; ctx.fillRect(x - 1, y - 4, 3, 7);
}

function shadow(ctx, x, y, size) {
  ctx.fillStyle = '#0c081566'; ctx.beginPath(); ctx.ellipse(x, y + 7, size, size * .33, 0, 0, Math.PI * 2); ctx.fill();
}

function drawEnemy(ctx, e, time, game) {
  shadow(ctx, e.x, e.y, e.r + 6);
  if (e.boss && e.mode === 'windup') {
    ctx.strokeStyle = '#ed847f'; ctx.lineWidth = 1; ctx.setLineDash([4, 5]);
    ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 9 + Math.sin(time * 9) * 3, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
  }
  if (e.type === 'butcher' && e.mode === 'windup' && e.aim) {
    ctx.strokeStyle = '#ec7a743b'; ctx.lineWidth = e.r * 1.5;
    ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(e.x + e.aim.x * 350, e.y + e.aim.y * 350); ctx.stroke();
    ctx.strokeStyle = '#ffab91b0'; ctx.lineWidth = 1; ctx.setLineDash([5, 5]); ctx.stroke(); ctx.setLineDash([]);
  }
  const bob = e.type === 'host' || e.type === 'bat' ? Math.sin(time * 5 + e.id) * 3 : Math.sin(time * 3 + e.id) * .7;
  sprite(ctx, e.type, e.x, e.y + bob, e.boss ? 2.5 : 1.7, e.flash > 0);
  if (e.type === 'butcher') {
    ctx.save(); ctx.translate(e.x + 31, e.y - 14); ctx.rotate(e.mode === 'windup' ? -.8 : .1);
    ctx.fillStyle = '#644a45'; ctx.fillRect(-2, 0, 4, 23);
    ctx.fillStyle = '#aea6b3'; ctx.fillRect(-2, -17, 17, 21); ctx.fillStyle = '#e5d8d5'; ctx.fillRect(12, -17, 3, 21);
    ctx.fillStyle = '#9b585e'; ctx.fillRect(7, 0, 5, 4); ctx.restore();
  }
  if (e.type === 'host' && game.enemies.some(enemy => enemy.type === 'generator' && enemy.hp > 0)) {
    ctx.strokeStyle = '#c2a1e588'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(e.x, e.y - 15, 40 + Math.sin(time * 4) * 2, 0, Math.PI * 2); ctx.stroke();
    for (const gen of game.enemies.filter(enemy => enemy.type === 'generator' && enemy.hp > 0)) {
      ctx.strokeStyle = '#b89be644'; ctx.lineWidth = 1; ctx.setLineDash([3, 6]); ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(gen.x, gen.y - 12); ctx.stroke(); ctx.setLineDash([]);
    }
  }
  if (!e.boss && e.hp < e.maxHp) {
    ctx.fillStyle = '#211522'; ctx.fillRect(e.x - 13, e.y - 31, 26, 3);
    ctx.fillStyle = e.type === 'generator' ? '#b89be6' : '#e5948d'; ctx.fillRect(e.x - 13, e.y - 31, 26 * e.hp / e.maxHp, 3);
  }
  if (e.mode === 'recover') {
    ctx.font = 'bold 8px monospace'; ctx.textAlign = 'center'; ctx.fillStyle = '#e8bb70'; ctx.fillText('VULNERABLE', e.x, e.y - 58);
    for (let i = 0; i < 3; i++) { ctx.fillStyle = '#e8bb70'; ctx.fillRect(e.x + Math.cos(time * 4 + i * 2) * 13, e.y - 45 + Math.sin(time * 4 + i * 2) * 3, 3, 3); }
  }
}

function drawPlayer(ctx, p, time) {
  shadow(ctx, p.x, p.y, 16);
  ctx.save();
  if (p.invulnerable > 0 && Math.floor(time * 12) % 2) ctx.globalAlpha = .5;
  sprite(ctx, 'hero', p.x, p.y + Math.sin(time * 3) * .5, 2);
  ctx.save(); ctx.translate(p.x, p.y - 5); ctx.rotate(p.facing + .55);
  ctx.fillStyle = '#665444'; ctx.fillRect(12, -2, 8, 4);
  ctx.fillStyle = '#e8bb70'; ctx.fillRect(18, -5, 3, 10);
  ctx.fillStyle = '#c8d8d5'; ctx.fillRect(21, -2, 18, 4);
  ctx.fillStyle = '#f2eee0'; ctx.fillRect(21, -2, 18, 1); ctx.fillRect(39, -1, 3, 2);
  ctx.restore(); ctx.restore();
  if (p.swing > 0) {
    ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.facing);
    ctx.strokeStyle = `rgba(248,220,162,${Math.min(1, p.swing / .18)})`; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.arc(0, 0, 44, -1.2, 1.2); ctx.stroke();
    ctx.strokeStyle = '#fff5d866'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, 49, -1.1, .9); ctx.stroke(); ctx.restore();
  }
  ctx.fillStyle = '#9ac9b1'; ctx.fillRect(p.x - 2, p.y + 15, 4, 2);
}

export function renderGame(ctx, game, time, reducedMotion = false) {
  const floor = game.floor || 0;
  ctx.imageSmoothingEnabled = false; ctx.save();
  ctx.clearRect(0, 0, WIDTH, HEIGHT);
  if (game.shake > 0 && !reducedMotion) ctx.translate(Math.sin(time * 90) * 2, Math.cos(time * 110) * 2);
  ctx.drawImage(staticRoom(floor), 0, 0);
  for (const hazard of game.hazards) {
    const waiting = hazard.delay > 0;
    ctx.fillStyle = hazard.type === 'pool' ? waiting ? '#a4d17b15' : '#8fb75e66' : waiting ? '#ec7a741c' : '#d9b5edaa';
    ctx.strokeStyle = waiting ? '#e8bb7099' : hazard.type === 'pool' ? '#b7d980bb' : '#f4d4ff'; ctx.lineWidth = 1;
    ctx.setLineDash(waiting ? [4, 4] : []);
    if (hazard.type === 'pool') { ctx.beginPath(); ctx.arc(hazard.x, hazard.y, hazard.r, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); }
    else { ctx.fillRect(hazard.x - hazard.w / 2, hazard.y - hazard.h / 2, hazard.w, hazard.h); ctx.strokeRect(hazard.x - hazard.w / 2, hazard.y - hazard.h / 2, hazard.w, hazard.h); }
    ctx.setLineDash([]);
  }
  for (const fx of game.effects) if (fx.type === 'trail') { ctx.globalAlpha = fx.life / fx.maxLife * .25; sprite(ctx, 'hero', fx.x, fx.y, 2); ctx.globalAlpha = 1; }
  for (const pickup of game.pickups) {
    const y = pickup.y + Math.sin(time * 4) * 2;
    ctx.fillStyle = '#9ac9b12a'; ctx.fillRect(pickup.x - 8, y - 8, 16, 16);
    ctx.fillStyle = '#b1dab2'; ctx.fillRect(pickup.x - 2, y - 5, 4, 10); ctx.fillRect(pickup.x - 5, y - 2, 10, 4);
  }
  const actors = [...PILLARS.map(p => ({ ...p, kind: 'pillar' })), ...game.enemies.map(e => ({ ...e, kind: 'enemy' })), { ...game.player, kind: 'player' }].sort((a, b) => a.y - b.y);
  for (const actor of actors) {
    if (actor.kind === 'pillar') pillar(ctx, actor, floor);
    else if (actor.kind === 'enemy') drawEnemy(ctx, actor, time, game);
    else drawPlayer(ctx, actor, time);
  }
  for (const shot of game.projectiles) {
    ctx.fillStyle = `${shot.color}33`; ctx.fillRect(shot.x - 7, shot.y - 7, 14, 14);
    ctx.fillStyle = shot.color; ctx.fillRect(shot.x - 3, shot.y - 3, 6, 6);
    ctx.fillStyle = '#f8eada'; ctx.fillRect(shot.x - 1, shot.y - 1, 2, 2);
  }
  for (const [x, y] of [[65, 43], [415, 43], [18, 210], [462, 210]]) torch(ctx, x, y, time, floor);
  const vignette = ctx.createRadialGradient(240, 215, 110, 240, 215, 310);
  vignette.addColorStop(0, '#100c1800'); vignette.addColorStop(1, '#08061099'); ctx.fillStyle = vignette; ctx.fillRect(0, 0, WIDTH, HEIGHT);
  if (!reducedMotion) for (let i = 0; i < 15; i++) {
    const x = (i * 79 + Math.sin(time * .3 + i) * 10) % 430 + 25;
    const y = 380 - ((time * (3 + i % 3) + i * 23) % 315);
    ctx.fillStyle = i % 3 ? '#e8bb7026' : '#e8bb7055'; ctx.fillRect(x, y, 1.5, 1.5);
  }
  for (const fx of game.effects) {
    if (fx.type === 'number') {
      ctx.globalAlpha = Math.min(1, fx.life * 3); ctx.font = 'bold 10px monospace'; ctx.textAlign = 'center';
      const y = fx.y - (1 - fx.life / fx.maxLife) * 22;
      ctx.fillStyle = '#100b18'; ctx.fillText(fx.value, fx.x + 1, y + 1); ctx.fillStyle = fx.color; ctx.fillText(fx.value, fx.x, y); ctx.globalAlpha = 1;
    } else if (fx.type === 'hit') {
      for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2, r = (1 - fx.life / fx.maxLife) * 21; ctx.fillStyle = i % 2 ? '#e8bb70' : '#f5e3c1'; ctx.fillRect(fx.x + Math.cos(a) * r, fx.y + Math.sin(a) * r, 3, 3); }
    }
  }
  ctx.restore();
}

export function renderPreview(ctx, time, reducedMotion = false) {
  const t = reducedMotion ? 1 : time;
  const scene = {
    floor: 0, shake: 0, effects: [], hazards: [], projectiles: [], pickups: [],
    player: { x: 238 + Math.sin(t * .5) * 4, y: 292, facing: -1.5, invulnerable: 0, swing: 0 },
    enemies: [
      { id: 1, type: 'butcher', x: 239, y: 163, r: 24, hp: 340, maxHp: 340, boss: true, mode: 'idle' },
      { id: 2, type: 'bat', x: 168 + Math.sin(t) * 3, y: 217, r: 8, hp: 26, maxHp: 26 },
      { id: 3, type: 'grunt', x: 330, y: 247, r: 10, hp: 38, maxHp: 38 },
    ],
  };
  renderGame(ctx, scene, t, reducedMotion);
  ctx.font = '7px monospace'; ctx.textAlign = 'center'; ctx.fillStyle = '#e8bb70'; ctx.fillText('MANU', scene.player.x, 253);
  ctx.fillStyle = '#e8bb7077'; ctx.fillRect(scene.player.x - 1, 257, 2, 3);
  ctx.fillStyle = '#f4d8ce'; ctx.font = 'bold 10px monospace'; ctx.fillText('!', 240, 91 + Math.sin(t * 2) * 2);
}
