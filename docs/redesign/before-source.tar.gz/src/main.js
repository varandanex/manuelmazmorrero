import { createGame, updateGame, chooseUpgrade, retryFloor, pauseGame, resumeGame, parseCheckpoint, formatTime, FLOORS, UPGRADES } from './game.js';
import { renderGame, renderPreview } from './render.js';

const $ = id => document.getElementById(id);
const canvas = $('arena');
const ctx = canvas.getContext('2d');
const previewCtx = $('preview').getContext('2d');
const storageKey = 'manu-dungeon-checkpoint-v1';
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
const keys = new Set();
const touch = { x: 0, y: 0, attack: false, dash: false };
let game = null, saved = null, lastFrame = 0, accumulator = 0, hudAt = 0;
let modalKind = '', helpWasPlaying = false, announcementUntil = 0, floorToastUntil = 0;
let joystickPointer = null, attackPointer = null, dashPointer = null;
let audioContext = null, soundEnabled = false;

function readSave() {
  try { saved = parseCheckpoint(localStorage.getItem(storageKey)); } catch { saved = null; }
  $('continue').hidden = !saved;
  $('start').className = saved ? 'text-button' : 'primary-button';
  $('start').innerHTML = saved ? 'Empezar una partida nueva ↗' : 'Entrar en la mazmorra <span aria-hidden="true">↘</span>';
}

function saveCheckpoint() {
  try { localStorage.setItem(storageKey, JSON.stringify(game.stageCheckpoint)); } catch { /* The game remains playable with storage disabled. */ }
}

function clearSave() {
  saved = null;
  try { localStorage.removeItem(storageKey); } catch { /* Private mode can reject storage. */ }
}

function unlockAudio() {
  if (!soundEnabled) return;
  try {
    audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    audioContext.resume().catch(() => {});
  } catch { soundEnabled = false; updateSoundLabel(); }
}

function playSound(name) {
  if (!soundEnabled || !audioContext || audioContext.state !== 'running') return;
  const sounds = { attack: [180, 70, .06], dash: [380, 180, .1], hurt: [120, 45, .16], kill: [410, 580, .08], boss: [80, 110, .4], charge: [120, 200, .22], win: [420, 840, .4], heal: [660, 880, .14] };
  const [from, to, duration] = sounds[name] || sounds.attack;
  const oscillator = audioContext.createOscillator(), gain = audioContext.createGain();
  oscillator.type = name === 'hurt' || name === 'boss' ? 'sawtooth' : 'triangle';
  const now = audioContext.currentTime;
  oscillator.frequency.setValueAtTime(from, now); oscillator.frequency.exponentialRampToValueAtTime(to, now + duration);
  gain.gain.setValueAtTime(.0001, now); gain.gain.exponentialRampToValueAtTime(.075, now + .01); gain.gain.exponentialRampToValueAtTime(.0001, now + duration);
  oscillator.connect(gain); gain.connect(audioContext.destination); oscillator.start(now); oscillator.stop(now + duration + .02);
  oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
}

function updateSoundLabel() {
  $('sound').setAttribute('aria-label', soundEnabled ? 'Desactivar sonido' : 'Activar sonido');
  $('sound').setAttribute('aria-pressed', String(soundEnabled));
  $('sound').title = soundEnabled ? 'Desactivar sonido' : 'Activar sonido';
  $('sound-label').textContent = soundEnabled ? 'ON' : 'OFF';
}

function clearInput() {
  keys.clear(); touch.x = 0; touch.y = 0; touch.attack = false; touch.dash = false;
  joystickPointer = null; attackPointer = null; dashPointer = null;
  $('joystick-knob').style.transform = ''; $('attack').classList.remove('pressed'); $('dash').classList.remove('pressed');
}

function setModal(kind, eyebrow, title, copy) {
  clearInput(); modalKind = kind;
  $('modal-eyebrow').textContent = eyebrow; $('modal-title').textContent = title; $('modal-copy').textContent = copy;
  $('modal-content').replaceChildren(); $('modal-actions').replaceChildren();
  if (!$('modal').open) $('modal').showModal();
}

function modalButton(label, action, secondary = false) {
  const button = document.createElement('button'); button.type = 'button'; button.className = secondary ? 'text-button' : 'primary-button'; button.textContent = label;
  button.addEventListener('click', action); $('modal-actions').append(button); return button;
}

function closeModal() { $('modal').close(); modalKind = ''; clearInput(); }

function start(checkpoint = null) {
  closeModal(); unlockAudio(); game = createGame(checkpoint);
  $('lobby').hidden = true; $('game-screen').hidden = false; document.body.classList.add('game-mode');
  window.scrollTo(0, 0); lastFrame = performance.now(); accumulator = 0; hudAt = 0;
  saveCheckpoint(); consumeEvents(); updateHud(); renderGame(ctx, game, game.elapsed, reducedMotion.matches);
}

function backToMenu() {
  closeModal(); game = null; document.body.classList.remove('game-mode');
  $('game-screen').hidden = true; $('lobby').hidden = false; readSave(); window.scrollTo(0, 0);
  (saved ? $('continue') : $('start')).focus({ preventScroll: true });
}

function showPause() {
  if (!game || !pauseGame(game)) return;
  setModal('pause', 'PAUSA PUBLICITARIA', 'Hasta el caos descansa.', 'La audiencia puede esperar. Tu partida está en pausa.');
  modalButton('Volver al espectáculo', () => { closeModal(); resumeGame(game); canvas.focus({ preventScroll: true }); });
  modalButton('Volver al menú', backToMenu, true);
  const note = document.createElement('p'); note.className = 'quiet-note'; note.textContent = 'Al salir se conserva el inicio del piso actual, no la sala exacta.'; $('modal-content').append(note);
}

function showHelp() {
  helpWasPlaying = game?.mode === 'playing';
  if (helpWasPlaying) pauseGame(game);
  setModal('help', 'MANUAL DE SUPERVIVENCIA', 'No mueras. Sobre todo eso.', 'Elimina dos oleadas y derrota al jefe de cada piso. Después, elige una mejora.');
  const rows = document.createElement('div'); rows.className = 'help-rows';
  const rules = [
    ['Muévete', 'Móvil: arrastra el joystick izquierdo. Ordenador: WASD o flechas.'],
    ['Ataca de cerca', 'Mantén pulsado ATACAR o espacio / J. Manu apunta al enemigo cercano.'],
    ['Esquiva el peligro', 'Pulsa ESQUIVAR o Mayús / K. Durante el impulso no recibes daño. Espera a que se recargue.'],
    ['Lee al enemigo', 'Las marcas en el suelo avisan antes de atacar. Aprovecha cuando un jefe esté VULNERABLE.'],
    ['No estás condenado', 'Las cruces verdes recuperan vida. Si caes, puedes repetir el piso conservando tus mejoras.'],
  ];
  for (const [title, copy] of rules) {
    const row = document.createElement('div'); row.className = 'help-row'; const strong = document.createElement('strong'); strong.textContent = title;
    row.append(strong, document.createTextNode(copy)); rows.append(row);
  }
  $('modal-content').append(rows);
  modalButton('Entendido. Más o menos.', closeHelp);
}

function closeHelp() {
  closeModal(); if (helpWasPlaying && game) resumeGame(game); helpWasPlaying = false;
}

function showUpgrade() {
  setModal('upgrade', `PISO 0${game.floor + 1} COMPLETADO`, 'Sigues vivo. Qué incómodo.', `La audiencia exige una segunda temporada.
Elige una ventaja. Recuperarás toda la vida.`);
  const list = document.createElement('div'); list.className = 'upgrade-list';
  for (const upgrade of UPGRADES) {
    const button = document.createElement('button'); button.className = 'upgrade-option';
    const icon = document.createElement('span'); icon.textContent = upgrade.icon; icon.setAttribute('aria-hidden', 'true');
    const text = document.createElement('div'), title = document.createElement('strong'), description = document.createElement('small');
    title.textContent = upgrade.name; description.textContent = upgrade.description; text.append(title, description); button.append(icon, text);
    button.addEventListener('click', () => {
      if (chooseUpgrade(game, upgrade.id)) { closeModal(); saveCheckpoint(); consumeEvents(); updateHud(); }
    }); list.append(button);
  }
  $('modal-content').append(list);
  list.querySelector('button').focus();
}

function showDeath() {
  setModal('dead', 'SEÑAL INTERRUMPIDA', 'Técnicamente, has muerto.', `«Pero has firmado tres temporadas. Levántate.»
Repite este piso con toda la vida y tus mejoras.`);
  addResults();
  modalButton('Otra oportunidad', () => { closeModal(); retryFloor(game); saveCheckpoint(); consumeEvents(); updateHud(); });
  modalButton('Salir al menú', backToMenu, true);
}

function addResults() {
  const grid = document.createElement('div'); grid.className = 'result-grid';
  for (const [number, label] of [[formatTime(game.elapsed), 'TIEMPO EN ANTENA'], [game.score, 'PUNTOS DE AUDIENCIA']]) {
    const item = document.createElement('div'), value = document.createElement('b'), caption = document.createElement('span');
    value.textContent = number; caption.textContent = label; item.append(value, caption); grid.append(item);
  }
  $('modal-content').append(grid);
}

function showVictory() {
  clearSave();
  setModal('won', 'LOGRO DESBLOQUEADO · LEYENDA DE LA MAZMORRA', 'Feliz cumpleaños, mazmorrero.', `Tres pisos. Tres jefes. Cero respeto por el reglamento.
«Has sobrevivido, Manu. Ahora intenta sobrevivir a otro año.»`);
  addResults();
  const note = document.createElement('p'); note.className = 'quiet-note'; note.textContent = `Criaturas derrotadas: ${game.kills} · Reintentos: ${game.deaths}. La organización niega toda responsabilidad.`; $('modal-content').append(note);
  modalButton('Otra ronda de malas decisiones', () => start());
  modalButton('Volver al menú', backToMenu, true);
}

function consumeEvents() {
  if (!game) return;
  const events = game.events.splice(0);
  for (const event of events) {
    if (event.type === 'sound') playSound(event.name);
    if (event.type === 'narrator') { $('narrator').textContent = event.text; $('mobile-narrator').textContent = event.text; }
    if (event.type === 'announcement') { $('announcement').textContent = event.text; announcementUntil = game.elapsed + 4.5; }
    if (event.type === 'floor') {
      floorToastUntil = game.elapsed + 2.6; announcementUntil = 0;
      $('room-number').textContent = `PISO 0${game.floor + 1}`; $('room-name').textContent = FLOORS[game.floor].name;
      $('floor-label').textContent = `PISO 0${game.floor + 1} / 03`;
      for (const item of document.querySelectorAll('[data-floor]')) {
        item.classList.toggle('active', Number(item.dataset.floor) === game.floor); item.classList.toggle('complete', Number(item.dataset.floor) < game.floor);
      }
      $('perks').textContent = game.perks.length ? game.perks.map(id => UPGRADES.find(u => u.id === id).name).join(' · ') : 'Tu optimismo. De momento.';
    }
    if (event.type === 'upgrade') showUpgrade();
    if (event.type === 'dead') showDeath();
    if (event.type === 'won') showVictory();
  }
}

function updateHud() {
  if (!game) return;
  const p = game.player;
  $('health-text').textContent = `${Math.ceil(p.hp)} / ${p.maxHp}`;
  $('health-fill').style.width = `${p.hp / p.maxHp * 100}%`;
  $('health-fill').style.background = p.hp < p.maxHp * .3 ? 'var(--danger)' : 'var(--mint)';
  $('timer').textContent = formatTime(game.elapsed); $('run-score').textContent = String(game.score).padStart(4, '0');
  $('dash').classList.toggle('cooldown', p.dashCooldown > 0);
  $('dash-label').textContent = p.dashCooldown > 0 ? `${p.dashCooldown.toFixed(1)} s` : 'ESQUIVAR';
  const boss = game.enemies.find(e => e.boss);
  $('boss-hud').hidden = !boss;
  if (boss) {
    $('boss-name').textContent = FLOORS[game.floor].boss;
    $('boss-fill').style.width = `${boss.hp / boss.maxHp * 100}%`;
    $('boss-state').textContent = boss.type === 'host' && game.enemies.some(e => e.type === 'generator') ? 'ESCUDO' : boss.mode === 'recover' ? 'VULNERABLE' : boss.mode === 'windup' ? '¡CUIDADO!' : '';
  }
  $('objective').textContent = game.phase === 'boss' ? FLOORS[game.floor].hint : game.phase === 'warning' ? 'Prepárate. Llega el jefe de piso.' : game.phase === 'intro' ? 'El espectáculo está a punto de empezar.' : game.phase === 'between' ? 'Un respiro. No te acostumbres.' : `OLEADA ${game.wave}/2 · ${game.enemies.length} enemigos restantes`;
  $('floor-toast').classList.toggle('visible', game.elapsed < floorToastUntil);
  $('announcement').classList.toggle('visible', game.elapsed < announcementUntil && game.elapsed > floorToastUntil);
}

function frame(now) {
  const delta = lastFrame ? Math.min(.1, Math.max(0, (now - lastFrame) / 1000)) : 0;
  lastFrame = now;
  if (game) {
    if (game.mode === 'playing' && !document.hidden) {
      accumulator += delta;
      while (accumulator >= 1 / 60) {
        const x = touch.x + (keys.has('ArrowRight') || keys.has('KeyD') ? 1 : 0) - (keys.has('ArrowLeft') || keys.has('KeyA') ? 1 : 0);
        const y = touch.y + (keys.has('ArrowDown') || keys.has('KeyS') ? 1 : 0) - (keys.has('ArrowUp') || keys.has('KeyW') ? 1 : 0);
        updateGame(game, 1 / 60, { x, y, attack: touch.attack || keys.has('Space') || keys.has('KeyJ'), dash: touch.dash });
        touch.dash = false; accumulator -= 1 / 60; consumeEvents();
        if (game.mode !== 'playing') { accumulator = 0; break; }
      }
    } else accumulator = 0;
    renderGame(ctx, game, game.elapsed, reducedMotion.matches);
    if (now - hudAt > 80) { updateHud(); hudAt = now; }
  } else if (!document.hidden) renderPreview(previewCtx, now / 1000, reducedMotion.matches);
  requestAnimationFrame(frame);
}

function joystickMove(event) {
  if (event.pointerId !== joystickPointer) return;
  const rect = $('joystick').getBoundingClientRect();
  let dx = event.clientX - rect.left - rect.width / 2, dy = event.clientY - rect.top - rect.height / 2;
  const radius = rect.width * .31, length = Math.hypot(dx, dy);
  if (length > radius) { dx *= radius / length; dy *= radius / length; }
  touch.x = dx / radius; touch.y = dy / radius;
  $('joystick-knob').style.transform = `translate(${dx}px, ${dy}px)`;
}

$('joystick').addEventListener('pointerdown', event => {
  if (game?.mode !== 'playing' || joystickPointer !== null) return;
  event.preventDefault(); joystickPointer = event.pointerId; $('joystick').setPointerCapture(event.pointerId); joystickMove(event);
});
$('joystick').addEventListener('pointermove', joystickMove);
for (const name of ['pointerup', 'pointercancel', 'lostpointercapture']) $('joystick').addEventListener(name, event => {
  if (event.pointerId !== joystickPointer) return;
  joystickPointer = null; touch.x = 0; touch.y = 0; $('joystick-knob').style.transform = '';
});
$('attack').addEventListener('pointerdown', event => {
  if (game?.mode !== 'playing' || attackPointer !== null) return;
  event.preventDefault(); unlockAudio(); attackPointer = event.pointerId; touch.attack = true; $('attack').setPointerCapture(event.pointerId); $('attack').classList.add('pressed');
});
for (const name of ['pointerup', 'pointercancel', 'lostpointercapture']) $('attack').addEventListener(name, event => {
  if (event.pointerId !== attackPointer) return;
  attackPointer = null; touch.attack = false; $('attack').classList.remove('pressed');
});
$('dash').addEventListener('pointerdown', event => {
  if (game?.mode !== 'playing' || dashPointer !== null) return;
  event.preventDefault(); unlockAudio(); dashPointer = event.pointerId; touch.dash = true; $('dash').setPointerCapture(event.pointerId); $('dash').classList.add('pressed');
});
for (const name of ['pointerup', 'pointercancel', 'lostpointercapture']) $('dash').addEventListener(name, event => {
  if (event.pointerId !== dashPointer) return;
  dashPointer = null; $('dash').classList.remove('pressed');
});
// Native keyboard activation of the on-screen action buttons remains supported.
$('attack').addEventListener('click', event => { if (!event.detail && game?.mode === 'playing') { touch.attack = true; setTimeout(() => { touch.attack = false; }, 100); } });
$('dash').addEventListener('click', event => { if (!event.detail && game?.mode === 'playing') touch.dash = true; });

window.addEventListener('keydown', event => {
  if ($('modal').open || !game) return;
  if (['Escape', 'KeyP'].includes(event.code)) { event.preventDefault(); showPause(); return; }
  if (game.mode !== 'playing') return;
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'KeyW', 'KeyA', 'KeyS', 'KeyD', 'Space', 'KeyJ', 'KeyK', 'ShiftLeft', 'ShiftRight'].includes(event.code)) {
    event.preventDefault(); keys.add(event.code);
    if (!event.repeat && ['ShiftLeft', 'ShiftRight', 'KeyK'].includes(event.code)) touch.dash = true;
  }
});
window.addEventListener('keyup', event => keys.delete(event.code));
window.addEventListener('blur', () => { clearInput(); showPause(); });
document.addEventListener('visibilitychange', () => { if (document.hidden) { clearInput(); showPause(); } });
$('modal').addEventListener('cancel', event => {
  event.preventDefault();
  if (modalKind === 'help') closeHelp();
  else if (modalKind === 'pause') { closeModal(); resumeGame(game); }
});
$('sound').addEventListener('click', () => { soundEnabled = !soundEnabled; updateSoundLabel(); unlockAudio(); if (soundEnabled) playSound('heal'); });
for (const id of ['help', 'lobby-help', 'sidebar-help']) $(id).addEventListener('click', showHelp);
$('pause').addEventListener('click', showPause);
$('continue').addEventListener('click', () => start(saved));
$('start').addEventListener('click', () => {
  if (!saved) { start(); return; }
  setModal('restart', 'NUEVO CONCURSANTE. EL MISMO, EN REALIDAD.', '¿Volvemos al primer piso?', 'Se sustituirá el progreso guardado de esta partida.');
  modalButton('Empezar desde cero', () => start()); modalButton('Conservar mi partida', closeModal, true);
});
readSave(); requestAnimationFrame(frame);
